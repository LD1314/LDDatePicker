//
//  ViewController.m
//  demo-DatePicker
//
//  Created by iOS Tedu on 16/8/9.
//  Copyright © 2016年 huaxu. All rights reserved.
//

#import "ViewController.h"
#import "LDDatePickerView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    LDDatePickerView *datePickerView = [[LDDatePickerView alloc] init];
    [datePickerView show];
    [datePickerView getDateWithBlock:^(NSDate *date) {
        NSTimeZone *zone = [NSTimeZone systemTimeZone];
        NSInteger interval = [zone secondsFromGMTForDate: date];
        NSDate *localeDate = [date  dateByAddingTimeInterval: interval];
        
        NSLog(@"%@",localeDate);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
