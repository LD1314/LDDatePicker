//
//  AppDelegate.h
//  demo-DatePicker
//
//  Created by iOS Tedu on 16/8/9.
//  Copyright © 2016年 huaxu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

